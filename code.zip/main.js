
/* rondom order of cards*/

const allCards = document.querySelectorAll('.memory-card');
(function shuffle() {
    allCards.forEach(card => {
        let randomPos = Math.floor(Math.random() * 12);
        card.style.order = randomPos;
    });
})();


/* jquery code */

$(function () {
    var cards = $('.memory-card');
    var hasFlippedCard = false;
    var lockBoard = false;
    var firstCard, secondCard;
    function flipCard() {
        if ($(this).hasClass('flip')) return;
        if ($(this) === firstCard) return;

        $(this).addClass('flip');
        console.log('dkncv');
        if (!hasFlippedCard) {
            // first click
            hasFlippedCard = true;
            firstCard = $(this);

            return;
        }

        // second click
        secondCard = $(this);

        checkForMatch();
    }
    function checkForMatch() {
        var isMatch = firstCard === secondCard;

        isMatch ? disableCards() : unflipCards();
    }
    function disableCards() {
        firstCard.removeEventListener('click', flipCard);
        secondCard.removeEventListener('click', flipCard);

        resetBoard();
    }

    function unflipCards() {
        lockBoard = true;

        setTimeout(() => {
            firstCard.removeClass('flip');
            secondCard.removeClass('flip');

            resetBoard();
        }, 1500);
    }

    function resetBoard() {
        hasFlippedCard = false;
        [firstCard, secondCard] = [null, null];
    }



    cards.siblings('.memory-card').not('.flip').on('click', flipCard);


});


